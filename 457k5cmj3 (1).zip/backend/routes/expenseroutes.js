const express = require("express");
const mysql = require("mysql2/promise");

const router = express.Router();

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "", // உங்கள் MySQL password இருந்தால் இங்கே இடவும்
  database: "expense_tracker"
});

// View and search/filter expenses
router.get("/", async (req, res) => {
  try {
    const { search = "", category = "" } = req.query;

    let sql = `SELECT * FROM expenses WHERE title LIKE ?`;
    const params = [`%${search}%`];

    if (category) {
      sql += ` AND category = ?`;
      params.push(category);
    }

    sql += ` ORDER BY expense_date DESC, id DESC`;

    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: "Could not load expenses" });
  }
});

// Add expense
router.post("/", async (req, res) => {
  try {
    const { title, amount, category, expense_date } = req.body;

    if (!title || !amount || !category || !expense_date) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const [result] = await db.query(
      `INSERT INTO expenses (title, amount, category, expense_date)
       VALUES (?, ?, ?, ?)`,
      [title, amount, category, expense_date]
    );

    res.status(201).json({ id: result.insertId, message: "Expense added" });
  } catch (error) {
    res.status(500).json({ error: "Could not add expense" });
  }
});

// Edit expense
router.put("/:id", async (req, res) => {
  try {
    const { title, amount, category, expense_date } = req.body;

    const [result] = await db.query(
      `UPDATE expenses
       SET title = ?, amount = ?, category = ?, expense_date = ?
       WHERE id = ?`,
      [title, amount, category, expense_date, req.params.id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ error: "Expense not found" });
    }

    res.json({ message: "Expense updated" });
  } catch (error) {
    res.status(500).json({ error: "Could not update expense" });
  }
});

// Delete expense
router.delete("/:id", async (req, res) => {
  try {
    const [result] = await db.query(
      "DELETE FROM expenses WHERE id = ?",
      [req.params.id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({ error: "Expense not found" });
    }

    res.json({ message: "Expense deleted" });
  } catch (error) {
    res.status(500).json({ error: "Could not delete expense" });
  }
});

module.exports = router;
