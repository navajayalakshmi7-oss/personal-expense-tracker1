const express = require("express");
const path = require("path");
const expenseRoutes = require("./routes/expenseRoutes");

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, "../frontend")));
app.use("/api/expenses", expenseRoutes);

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Expense Tracker running at http://localhost:${PORT}`);
});
