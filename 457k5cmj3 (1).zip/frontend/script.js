const $ = id => document.getElementById(id);
let editingId = null;

$("date").valueAsDate = new Date();

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });

  if (!response.ok) {
    const result = await response.json();
    throw new Error(result.error || "Something went wrong");
  }

  return response.json();
}

async function loadExpenses() {
  const params = new URLSearchParams({
    search: $("search").value,
    category: $("filter").value
  });

  try {
    const expenses = await request(`/api/expenses?${params}`);
    renderExpenses(expenses);
    await loadTotals();
  } catch (error) {
    $("list").innerHTML = `<li>${error.message}. Check that the server is running.</li>`;
  }
}

function renderExpenses(expenses) {
  $("list").innerHTML = expenses.length
    ? expenses.map(e => `
      <li>
        <span>
          ${escapeHTML(e.title)} · ${escapeHTML(e.category)}
          · ${String(e.expense_date).slice(0, 10)} — ₹${Number(e.amount).toFixed(2)}
        </span>
        <span class="actions">
          <button class="edit" onclick="editExpense(${e.id})">Edit</button>
          <button class="delete" onclick="deleteExpense(${e.id})">Delete</button>
        </span>
      </li>`).join("")
    : "<li>No expenses found.</li>";
}

async function loadTotals() {
  const expenses = await request("/api/expenses");
  const total = expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  const month = new Date().toISOString().slice(0, 7);
  const monthly = expenses
    .filter(e => String(e.expense_date).slice(0, 7) === month)
    .reduce((sum, e) => sum + Number(e.amount), 0);

  $("total").textContent = `₹${total.toFixed(2)}`;
  $("monthly").textContent = `₹${monthly.toFixed(2)}`;
}

$("expenseForm").addEventListener("submit", async event => {
  event.preventDefault();

  const expense = {
    title: $("title").value.trim(),
    amount: Number($("amount").value),
    category: $("category").value,
    expense_date: $("date").value
  };

  try {
    await request(
      editingId ? `/api/expenses/${editingId}` : "/api/expenses",
      {
        method: editingId ? "PUT" : "POST",
        body: JSON.stringify(expense)
      }
    );

    resetForm();
    await loadExpenses();
    location.hash = "expenses";
  } catch (error) {
    alert(error.message);
  }
});

async function editExpense(id) {
  try {
    const expenses = await request("/api/expenses");
    const expense = expenses.find(e => e.id === id);
    if (!expense) return;

    editingId = id;
    $("title").value = expense.title;
    $("amount").value = expense.amount;
    $("category").value = expense.category;
    $("date").value = String(expense.expense_date).slice(0, 10);
    $("formTitle").textContent = "Edit Expense";
    $("submitBtn").textContent = "Save Changes";
    location.hash = "add";
  } catch (error) {
    alert(error.message);
  }
}

async function deleteExpense(id) {
  if (!confirm("Delete this expense?")) return;

  try {
    await request(`/api/expenses/${id}`, { method: "DELETE" });
    await loadExpenses();
  } catch (error) {
    alert(error.message);
  }
}

function resetForm() {
  editingId = null;
  $("expenseForm").reset();
  $("date").valueAsDate = new Date();
  $("formTitle").textContent = "Add Expense";
  $("submitBtn").textContent = "Add Expense";
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));
}

$("search").addEventListener("input", loadExpenses);
$("filter").addEventListener("change", loadExpenses);
loadExpenses();
